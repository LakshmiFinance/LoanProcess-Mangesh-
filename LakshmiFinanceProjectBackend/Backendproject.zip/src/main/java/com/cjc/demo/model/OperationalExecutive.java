package com.cjc.demo.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

import com.cjc.demo.model.generalclasses.ViewEnquiry;


@Entity
public class OperationalExecutive
{
	@Id
private int oeId;

private String oeName;
 private String username;
 
 private String password;
 
 


 
 




 
 
}
