package com.cjc.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LakshmiFinanceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
