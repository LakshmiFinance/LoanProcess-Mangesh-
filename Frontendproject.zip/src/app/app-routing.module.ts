import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CibilscoreComponent } from './generalcomponent/cibilscore/cibilscore.component';
import { LoanapprovalComponent } from './generalcomponent/loanapproval/loanapproval.component';
import { LoanmanagementsystemComponent } from './generalcomponent/loanmanagementsystem/loanmanagementsystem.component';
import { LoanverificationComponent } from './generalcomponent/loanverification/loanverification.component';
import { ViewenquiryComponent } from './generalcomponent/viewenquiry/viewenquiry.component';
import { LoginComponent } from './login/login.component';
import { AccounthandlerComponent } from './mastercomponent/accounthandler/accounthandler.component';
import { CreditmanagerComponent } from './mastercomponent/creditmanager/creditmanager.component';
import { CustomerpersonaldetailsComponent } from './mastercomponent/customerpersonaldetails/customerpersonaldetails.component';
import { LoandetailsComponent } from './mastercomponent/loandetails/loandetails.component';
import { OperationalexecutiveComponent } from './mastercomponent/operationalexecutive/operationalexecutive.component';
import { RelationalexecutivedetailsComponent } from './mastercomponent/relationalexecutivedetails/relationalexecutivedetails.component';
import { VehicledetailsComponent } from './mastercomponent/vehicledetails/vehicledetails.component';

const routes: Routes = [
{

  path:'customer', component:CustomerpersonaldetailsComponent
},
{
  path:'', component:LoginComponent
},
{

  path:'oe', component:OperationalexecutiveComponent
},
{

  path:'oe/ve', component:ViewenquiryComponent
},

{

  path:'oe/cb', component:CibilscoreComponent
},

{

  path:'oe/lc', component:LoanmanagementsystemComponent
},
{

  path:'oe/la', component:LoanapprovalComponent
},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
