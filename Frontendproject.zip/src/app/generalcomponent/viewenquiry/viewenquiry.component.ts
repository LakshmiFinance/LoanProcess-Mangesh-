import { Component, OnInit } from '@angular/core';
import { Customerpersonaldetails } from 'src/app/model/customerpersonaldetails';
import { CommonserviceService } from 'src/app/shared/commonservice.service';

@Component({
  selector: 'app-viewenquiry',
  templateUrl: './viewenquiry.component.html',
  styleUrls: ['./viewenquiry.component.css']
})
export class ViewenquiryComponent implements OnInit {

  customerlist:Customerpersonaldetails[]
  constructor(private _common:CommonserviceService)
   { 

   }

  ngOnInit(): void 
  {


    this._common.getData().subscribe((cuslist:Customerpersonaldetails[])=>{
      this.customerlist=cuslist;
    }
    )
  }

}
