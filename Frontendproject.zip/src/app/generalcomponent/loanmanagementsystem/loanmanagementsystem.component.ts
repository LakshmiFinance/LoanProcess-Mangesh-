import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Loanmanagementsystem } from 'src/app/generalmodel/loanmanagementsystem';
import { CommonserviceService } from 'src/app/shared/commonservice.service';

@Component({
  selector: 'app-loanmanagementsystem',
  templateUrl: './loanmanagementsystem.component.html',
  styleUrls: ['./loanmanagementsystem.component.css']
})
export class LoanmanagementsystemComponent implements OnInit {
loanlist:Loanmanagementsystem[]
  myForm:FormGroup;
  constructor(private _common:CommonserviceService, private _fb:FormBuilder) { 


    this.myForm=this._fb.group(
      {
            LoanemiId:[''],
        customerId:[''],
        annualinterestRate:[''],
        numberofYear:[''],
          loanAmount:[''],
        monthlypayment:['']
   }
   )
  }

  ngOnInit(): void 
  {

    this._common.getloan().subscribe((loanlist:Loanmanagementsystem[])=>{
      this.loanlist=loanlist;
    })
  }

  submitloan()


  {
    console.log(this.myForm.value);
    this._common.saveloan(this.myForm.value).subscribe(res=>{this.ngOnInit()})
  
  
  }

}
