import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanmanagementsystemComponent } from './loanmanagementsystem.component';

describe('LoanmanagementsystemComponent', () => {
  let component: LoanmanagementsystemComponent;
  let fixture: ComponentFixture<LoanmanagementsystemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanmanagementsystemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanmanagementsystemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
