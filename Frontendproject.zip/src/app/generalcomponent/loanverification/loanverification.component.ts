import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loanverification',
  templateUrl: './loanverification.component.html',
  styleUrls: ['./loanverification.component.css']
})
export class LoanverificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
