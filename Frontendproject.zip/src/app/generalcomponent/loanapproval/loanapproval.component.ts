import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Loanapproval } from 'src/app/generalmodel/loanapproval';
import { CommonserviceService } from 'src/app/shared/commonservice.service';

@Component({
  selector: 'app-loanapproval',
  templateUrl: './loanapproval.component.html',
  styleUrls: ['./loanapproval.component.css']
})
export class LoanapprovalComponent implements OnInit {
   
  myForm:FormGroup;

  constructor(private _common:CommonserviceService,private _fb:FormBuilder) 
  { 

    this.myForm=this._fb.group(
      {
        loanId:[''],
	
	loanType:[''],
	
	 sanctionAmount:[''],
	
 loanapporvalDate:[''],
	
	 interestRate:[''],

   loanStatus:['']
   

   }
   )
  }

  loanapprovallist:Loanapproval[]

  ngOnInit(): void 
  {
    this._common.getloanApproval().subscribe((loanapprovallist:Loanapproval[])=>{
      this.loanapprovallist=loanapprovallist;
    })
  }


  submitloan()


{
  console.log(this.myForm.value);
  this._common.saveloanApproval(this.myForm.value).subscribe(res=>{this.ngOnInit()})


}

}
