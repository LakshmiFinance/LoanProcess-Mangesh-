import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Cibilscore } from 'src/app/generalmodel/cibilscore';
import { CommonserviceService } from 'src/app/shared/commonservice.service';

@Component({
  selector: 'app-cibilscore',
  templateUrl: './cibilscore.component.html',
  styleUrls: ['./cibilscore.component.css']
})
export class CibilscoreComponent implements OnInit {

  cibilist:Cibilscore[]

  myForm:FormGroup;
  constructor(private _common:CommonserviceService,private _fb:FormBuilder) 
  {

    
    this.myForm=this._fb.group(
      {
        customerId:[''],
        cibilscoreId:[''],
    
    cibilStatus:[''],
    cibilRemark:[''],
        cibilScore:['']    

   }
   )
  }

  ngOnInit(): void 
  {
    this._common.getCibil().subscribe((cibillist:Cibilscore[])=>{
      this.cibilist=cibillist;
    
    })
  }

  submitcibil()


{
  console.log(this.myForm.value);
  this._common.savecibil(this.myForm.value).subscribe(res=>{this.ngOnInit()})


}

 
}
