import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Cibilscore } from '../generalmodel/cibilscore';
import { Loanapproval } from '../generalmodel/loanapproval';
import { Loanmanagementsystem } from '../generalmodel/loanmanagementsystem';

import { Customerpersonaldetails } from '../model/customerpersonaldetails';

@Injectable({
  providedIn: 'root'
})
export class CommonserviceService {

  constructor(private _http:HttpClient) { }
  saveData(cpd:Customerpersonaldetails):Observable<Customerpersonaldetails>
  {
    return this._http.post<Customerpersonaldetails>("http://localhost:9091/save",cpd);
  }

  
    getData():Observable<Customerpersonaldetails[]>
    {
  return this._http.get<Customerpersonaldetails[]>("http://localhost:9091/getData");
    }

    savecibil(cbl:Cibilscore):Observable<Cibilscore[]>
    {
      return this._http.post<Cibilscore[]>("http://localhost:9091/cibil",cbl);
    }
  
   
    getCibil():Observable<Cibilscore[]>
    {
      return this._http.get<Cibilscore[]>("http://localhost:9091/getcibil");
    }

    saveloan(sl:Loanmanagementsystem):Observable<Loanmanagementsystem[]>
    {
      return this._http.post<Loanmanagementsystem[]>("http://localhost:9091/emi",sl);
    }

    getloan():Observable<Loanmanagementsystem[]>
    {
      return this._http.get<Loanmanagementsystem[]>("http://localhost:9091/getemi");
    }



    saveloanApproval(la:Loanapproval):Observable<Loanapproval[]>
    {
      return this._http.post<Loanapproval[]>("http://localhost:9091/saveloan",la);
    }


    getloanApproval():Observable<Loanapproval[]>
    {
      return this._http.get<Loanapproval[]>("http://localhost:9091/getloan");
    }

    
}
