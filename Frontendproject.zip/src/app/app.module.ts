import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerpersonaldetailsComponent } from './mastercomponent/customerpersonaldetails/customerpersonaldetails.component';
import { VehicledetailsComponent } from './mastercomponent/vehicledetails/vehicledetails.component';

import { LoandetailsComponent } from './mastercomponent/loandetails/loandetails.component';
import { RelationalexecutivedetailsComponent } from './mastercomponent/relationalexecutivedetails/relationalexecutivedetails.component';
import { OperationalexecutiveComponent } from './mastercomponent/operationalexecutive/operationalexecutive.component';
import { CreditmanagerComponent } from './mastercomponent/creditmanager/creditmanager.component';
import { AccounthandlerComponent } from './mastercomponent/accounthandler/accounthandler.component';
import { CibilscoreComponent } from './generalcomponent/cibilscore/cibilscore.component';
import { ViewenquiryComponent } from './generalcomponent/viewenquiry/viewenquiry.component';
import { LoanverificationComponent } from './generalcomponent/loanverification/loanverification.component';
import { LoanapprovalComponent } from './generalcomponent/loanapproval/loanapproval.component';
import { LoanmanagementsystemComponent } from './generalcomponent/loanmanagementsystem/loanmanagementsystem.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import{  HttpClientModule } from '@angular/common/http';
import { LoanemicalculationComponent } from './loanemicalculation/loanemicalculation.component';
import { LoginComponent } from './login/login.component';
@NgModule({
  declarations: [
    AppComponent,
    CustomerpersonaldetailsComponent,

    VehicledetailsComponent,
  
    LoandetailsComponent,
    RelationalexecutivedetailsComponent,
    OperationalexecutiveComponent,
    CreditmanagerComponent,
    AccounthandlerComponent,
    CibilscoreComponent,
    ViewenquiryComponent,
    LoanverificationComponent,
    LoanapprovalComponent,
    LoanmanagementsystemComponent,
    LoanemicalculationComponent,
    LoginComponent
  ],
  imports: [
    
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
