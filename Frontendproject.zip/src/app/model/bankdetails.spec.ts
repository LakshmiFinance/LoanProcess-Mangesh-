import { Bankdetails } from './bankdetails';

describe('Bankdetails', () => {
  it('should create an instance', () => {
    expect(new Bankdetails()).toBeTruthy();
  });
});
