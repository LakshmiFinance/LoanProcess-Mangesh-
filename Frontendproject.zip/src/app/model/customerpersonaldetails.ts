import { logging } from "protractor";

export class Customerpersonaldetails 
{

customerId:number;
customerName:string;
customerGender:string;
customerMobileNo:number;
customerAge:number;
customerDob:string;
customerEmail:string;
customerPanCardNo:string;
bankDetails:any;
Loandetails:any;
customerAddressDetails:any;
VehicleDetails:any;
 
}
