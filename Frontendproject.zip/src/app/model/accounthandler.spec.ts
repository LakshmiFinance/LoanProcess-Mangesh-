import { Accounthandler } from './accounthandler';

describe('Accounthandler', () => {
  it('should create an instance', () => {
    expect(new Accounthandler()).toBeTruthy();
  });
});
