import { Operationalexecutive } from './operationalexecutive';

describe('Operationalexecutive', () => {
  it('should create an instance', () => {
    expect(new Operationalexecutive()).toBeTruthy();
  });
});
