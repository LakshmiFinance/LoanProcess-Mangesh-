export class Bankdetails
 {

     bankId:number;
      bankName:string;        
	  accountNo:number;
	  bankIfsc:string;
	   bankMicr:string;
        bankAddress:string;
	   branchName:string; 
}
