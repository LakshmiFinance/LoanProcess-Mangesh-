import { Relationalexecutivedetails } from './relationalexecutivedetails';

describe('Relationalexecutivedetails', () => {
  it('should create an instance', () => {
    expect(new Relationalexecutivedetails()).toBeTruthy();
  });
});
