export class Loandetails 
{

     loanId:number
	 loanAmount:number;
	 loanStatus:true;
	 loanType:string;
	tenure:number;
}
