export class Relationalexecutivedetails 
{
      reId:number;
	
	  rName:string;
	
	  username:string;
	
	  password:string;
}
