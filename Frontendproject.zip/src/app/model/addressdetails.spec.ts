import { Addressdetails } from './addressdetails';

describe('Addressdetails', () => {
  it('should create an instance', () => {
    expect(new Addressdetails()).toBeTruthy();
  });
});
