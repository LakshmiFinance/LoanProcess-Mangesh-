export class Accounthandler 
{
     acid:number;
	
	 acName:string;
	
	 username:string;
		password:string;
}
