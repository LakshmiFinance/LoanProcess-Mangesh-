export class Addressdetails 
{
     
}
