import { Customerpersonaldetails } from './customerpersonaldetails';

describe('Customerpersonaldetails', () => {
  it('should create an instance', () => {
    expect(new Customerpersonaldetails()).toBeTruthy();
  });
});
