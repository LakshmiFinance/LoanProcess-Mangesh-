import { Vehicledetails } from './vehicledetails';

describe('Vehicledetails', () => {
  it('should create an instance', () => {
    expect(new Vehicledetails()).toBeTruthy();
  });
});
