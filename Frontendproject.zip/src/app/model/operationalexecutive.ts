export class Operationalexecutive
 {

    oeId:number;

 oeName:string;
  username:string;
 
  password:string;
}
