export class Vehicledetails 
{
     vehicleId:number;
	 modelNo:string;
     vehicleName:string;
	 vehicleType:string;
	dealer:string;
	 price:number;
	onRoadPrice:number;
}
