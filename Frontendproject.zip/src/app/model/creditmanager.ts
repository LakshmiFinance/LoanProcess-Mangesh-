export class Creditmanager
 {

	cmId:number;
	
	 cmName:string;
	
	username:string;
	
	 password:string;
}
