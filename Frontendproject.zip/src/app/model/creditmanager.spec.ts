import { Creditmanager } from './creditmanager';

describe('Creditmanager', () => {
  it('should create an instance', () => {
    expect(new Creditmanager()).toBeTruthy();
  });
});
