import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loanemicalculation',
  templateUrl: './loanemicalculation.component.html',
  styleUrls: ['./loanemicalculation.component.css']
})
export class LoanemicalculationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
