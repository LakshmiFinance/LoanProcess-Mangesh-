import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanemicalculationComponent } from './loanemicalculation.component';

describe('LoanemicalculationComponent', () => {
  let component: LoanemicalculationComponent;
  let fixture: ComponentFixture<LoanemicalculationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanemicalculationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanemicalculationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
