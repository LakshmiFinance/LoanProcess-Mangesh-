import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operationalexecutive',
  templateUrl: './operationalexecutive.component.html',
  styleUrls: ['./operationalexecutive.component.css']
})
export class OperationalexecutiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
