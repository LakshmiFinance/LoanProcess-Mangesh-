import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-vehicledetails',
  templateUrl: './vehicledetails.component.html',
  styleUrls: ['./vehicledetails.component.css']
})
export class VehicledetailsComponent implements OnInit {

  
myForm:FormGroup;
  constructor(private _fb:FormBuilder)
   
  
  { 


    this.myForm=this._fb.group(
      {
        
customerId:[''],
VehicleDetails:this._fb.array([

  this._fb.group({

    vehicleId:[''],
    modelNo:[''],
      vehicleName:[''],
    vehicleType:[''],
   dealer:[''],
    price:[''],
   onRoadPrice:[''],
  })
])



      }
    )
  }

  ngOnInit(): void {
  }

}
