import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { CommonserviceService } from 'src/app/shared/commonservice.service';

@Component({
  selector: 'app-customerpersonaldetails',
  templateUrl: './customerpersonaldetails.component.html',
  styleUrls: ['./customerpersonaldetails.component.css']
})
export class CustomerpersonaldetailsComponent implements OnInit {

  personalInfo:boolean=false;
  addressInfo:boolean=false;
  bankInfo:boolean=false;

myForm:FormGroup;

  constructor(private _fb:FormBuilder,private _common:CommonserviceService) { 

    this.myForm=this._fb.group(
      {
        
customerId:[''],
customerName:[''],
customerGender:[''],
customerMobileNo:[''],
customerAge:[''],
customerDob:[''],
customerEmail:[''],
customerPanCardNo:[''],

    
customerAddressDetails:this._fb.array
    ([

      this._fb.group({
    
        customerAddressId:[''],
        houseNo:[''],
         area:[''],
       city:[''],
         state:[''],
         country:[''],
      }
      )
    ]
    ),

    bankDetails:this._fb.array([
      this._fb.group({
        bankName:[''],        
        accountNo:[''],
        bankIfsc:[''],
         bankMicr:[''],
            bankAddress:[''],
         branchName:[''],
      }
      )
    
    
    ])





      }
    )
  }


  ngOnInit(): void {
  }
submit()


{
  console.log(this.myForm.value);
  this._common.saveData(this.myForm.value).subscribe(res=>{})
}

personalinfo(val)
{
this.personalInfo=val
}
addressinfo(val)
{
  this.addressInfo=val
}
bankinfo(val)
{
  this.bankInfo=val
}

}
