import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerpersonaldetailsComponent } from './customerpersonaldetails.component';

describe('CustomerpersonaldetailsComponent', () => {
  let component: CustomerpersonaldetailsComponent;
  let fixture: ComponentFixture<CustomerpersonaldetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerpersonaldetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerpersonaldetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
