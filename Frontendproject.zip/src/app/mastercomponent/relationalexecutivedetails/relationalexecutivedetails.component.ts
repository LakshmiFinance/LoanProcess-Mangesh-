import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-relationalexecutivedetails',
  templateUrl: './relationalexecutivedetails.component.html',
  styleUrls: ['./relationalexecutivedetails.component.css']
})
export class RelationalexecutivedetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
