import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RelationalexecutivedetailsComponent } from './relationalexecutivedetails.component';

describe('RelationalexecutivedetailsComponent', () => {
  let component: RelationalexecutivedetailsComponent;
  let fixture: ComponentFixture<RelationalexecutivedetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RelationalexecutivedetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RelationalexecutivedetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
