import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accounthandler',
  templateUrl: './accounthandler.component.html',
  styleUrls: ['./accounthandler.component.css']
})
export class AccounthandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
