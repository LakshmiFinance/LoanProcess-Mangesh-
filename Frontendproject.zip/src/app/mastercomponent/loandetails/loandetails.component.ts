import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-loandetails',
  templateUrl: './loandetails.component.html',
  styleUrls: ['./loandetails.component.css']
})
export class LoandetailsComponent implements OnInit
 {
  myForm:FormGroup;
  constructor(private _fb:FormBuilder) { 

    this.myForm=this._fb.group(
      {
        
customerId:[''],

    Loandetails:this._fb.array([

      this._fb.group({
    
        loanAmount:[''],
       loanStatus:true,
       loanType:[''],
      tenure:[''],
      }
      )
    ]
    )
  }
    )
    
    
  }


  ngOnInit(): void {
  }

}
