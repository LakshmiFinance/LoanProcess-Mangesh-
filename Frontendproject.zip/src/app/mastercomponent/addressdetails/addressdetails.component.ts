import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addressdetails',
  templateUrl: './addressdetails.component.html',
  styleUrls: ['./addressdetails.component.css']
})
export class AddressdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
