import { Cibilscore } from './cibilscore';

describe('Cibilscore', () => {
  it('should create an instance', () => {
    expect(new Cibilscore()).toBeTruthy();
  });
});
