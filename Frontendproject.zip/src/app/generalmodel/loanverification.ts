export class Loanverification 
{
    loanId:number;
    loanType:string;
    loanAmount:number;
    loanDate:string;
    interestRate:number;
    issueDate:string;
    assetDate:string;
    guarantorName:string;
}
