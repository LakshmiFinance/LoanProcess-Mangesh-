export class Loanmanagementsystem 
{
     LoanemiId:number;
	 customerId:number;
	 annualinterestRate:number;
	 numberofYear:number;
     loanAmount:number;
	 monthlypayment:number;
}
