import { Loanmanagementsystem } from './loanmanagementsystem';

describe('Loanmanagementsystem', () => {
  it('should create an instance', () => {
    expect(new Loanmanagementsystem()).toBeTruthy();
  });
});
