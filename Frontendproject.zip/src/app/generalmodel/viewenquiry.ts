export class Viewenquiry 
{
    EnquiryId:number;
    EnquiryName:string;
    MobileNo:number;
}
