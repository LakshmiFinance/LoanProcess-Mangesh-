import { Viewenquiry } from './viewenquiry';

describe('Viewenquiry', () => {
  it('should create an instance', () => {
    expect(new Viewenquiry()).toBeTruthy();
  });
});
