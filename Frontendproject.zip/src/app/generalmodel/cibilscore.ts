export class Cibilscore 
{
    cibilscoreId:number;
    customerId:number;
    cibilScore:number;
    cibilStatus:string;
    cibilRemark:string;
}
