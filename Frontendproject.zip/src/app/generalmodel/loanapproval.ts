export class Loanapproval 
{
    loanId:number;
	
	loanType:string;
	
	 sanctionAmount:number;
	
 loanapporvalDate:string;
	
	 interestRate:number;

	 loanStatus:string

}
