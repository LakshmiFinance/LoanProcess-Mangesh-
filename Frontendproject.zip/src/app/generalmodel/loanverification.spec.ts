import { Loanverification } from './loanverification';

describe('Loanverification', () => {
  it('should create an instance', () => {
    expect(new Loanverification()).toBeTruthy();
  });
});
